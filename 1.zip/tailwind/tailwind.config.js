/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
       "./src/**/*.{html,js}",
       "./project/**/*.{html,js}",
       
      
      ],
  theme: {
    extend: { 
    },
   
  },
  plugins: [],
}

